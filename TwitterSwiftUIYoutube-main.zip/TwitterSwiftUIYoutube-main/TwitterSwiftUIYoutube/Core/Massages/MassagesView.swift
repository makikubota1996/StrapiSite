//
//  MassagesView.swift
//  TwitterSwiftUIYoutube
//
//  Created by 田中大地 on 2022/04/30.
//

import SwiftUI

struct MassagesView: View {
    var body: some View {
        Text("Massages")
    }
}

struct MassagesView_Previews: PreviewProvider {
    static var previews: some View {
        MassagesView()
    }
}
